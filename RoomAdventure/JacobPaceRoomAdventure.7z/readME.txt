I had only one small issue, it caused crashes so I deleted the lines, but idk why it would throw an error.  When i used the delGrabbales function, it would throw
the "x is not in room.grabbables" but I had a print statement just before it printing out that room's grabbables and it was there so idek anymore.
It works fine now.